# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pytest-cov>=4.0.0,<5.0.0', 'pytest>=7.2.0,<8.0.0', 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/FillEvans/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/FillEvans/python-project-50/actions)\n[![Python CI](https://github.com/FillEvans/python-project-50/actions/workflows/main.yml/badge.svg)](https://github.com/FillEvans/python-project-50/actions/workflows/main.yml)\n<a href="https://codeclimate.com/github/FillEvans/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/a0c7ccdb0a8c018a5899/maintainability" /></a>\n<a href="https://codeclimate.com/github/FillEvans/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/a0c7ccdb0a8c018a5899/test_coverage" /></a>\n\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
