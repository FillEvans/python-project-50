### Hexlet tests and linter status:
[![Actions Status](https://github.com/FillEvans/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/FillEvans/python-project-50/actions)
[![Python CI](https://github.com/FillEvans/python-project-50/actions/workflows/main.yml/badge.svg)](https://github.com/FillEvans/python-project-50/actions/workflows/main.yml)
<a href="https://codeclimate.com/github/FillEvans/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/a0c7ccdb0a8c018a5899/maintainability" /></a>